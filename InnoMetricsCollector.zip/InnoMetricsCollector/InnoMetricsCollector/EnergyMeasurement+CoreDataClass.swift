//
//  Abc.swift
//  InnoMetricsCollector
//
//  Created by Dragos Strugar on 26.02.2020.
//  Copyright © 2020 Innopolis University. All rights reserved.
//

import Foundation
import CoreData

public class EnergyMeasurement: NSManagedObject {
}
