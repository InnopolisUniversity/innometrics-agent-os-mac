//
//  Metric+CoreDataClass.swift
//  InnoMetricsCollector
//
//  Created by Denis Zaplatnikov on 11/01/2017.
//  Copyright © 2017 Denis Zaplatnikov. All rights reserved.
//

import Foundation
import CoreData

public class Metric: NSManagedObject {
    
    public var isHidden: Bool = true

}
