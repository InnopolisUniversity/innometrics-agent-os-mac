//
//  InnoMetricsTestApp-Bridging-Header.h
//  InnoMetricsCollector
//
//  Created by Denis Zaplatnikov on 11/01/2017.
//  Copyright © 2017 Denis Zaplatnikov. All rights reserved.
//

#ifndef InnoMetricsTestApp_Bridging_Header_h
#define InnoMetricsTestApp_Bridging_Header_h


#endif /* InnoMetricsTestApp_Bridging_Header_h */
