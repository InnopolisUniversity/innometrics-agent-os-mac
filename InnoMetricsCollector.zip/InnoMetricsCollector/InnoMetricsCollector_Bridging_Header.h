//
//  InnoMetricsCollector_Bridging_Header.h
//  InnoMetricsCollector
//
//  Created by Denis Zaplatnikov on 11/01/2017.
//  Copyright © 2018 Denis Zaplatnikov and Pavel Kotov. All rights reserved.
//

#ifndef InnoMetricsCollector_Bridging_Header_h
#define InnoMetricsCollector_Bridging_Header_h

#include <ifaddrs.h>

#endif /* InnoMetricsCollector_Bridging_Header_h */
